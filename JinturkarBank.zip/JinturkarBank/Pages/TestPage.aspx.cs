﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Pages_TestPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Text = DateTime.Now.ToString();
        Label2.Text = DateTime.Now.ToString();

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Label2.Text = "Button 2 CLicked" + DateTime.Now.ToString();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Label1.Text = "Button 1 CLicked" + DateTime.Now.ToString();
    }
    protected void Timer1_Tick(object sender, EventArgs e)
    {
        Label3.Text = DateTime.Now.Millisecond.ToString();
    }
    protected void Button3_Click(object sender, EventArgs e)
    {


        wsWeather.WeatherSoapClient w = new wsWeather.WeatherSoapClient("WeatherSoap");
        
         wsWeather.WeatherReturn fr =  w.GetCityWeatherByZIP(txtZipCode.Text);

         Literal1.Text = fr.City.ToString() + ' ' + fr.Temperature.ToString();
           
    }
}
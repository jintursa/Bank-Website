﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Pages_LoanManagement : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void gvCustomerLoanList_SelectedIndexChanged(object sender, EventArgs e)
    {
        JinturkarLoan.PaymentCalculator Loan = new JinturkarLoan.PaymentCalculator();
        Loan.Principal = double.Parse(gvCustomerLoanList.SelectedRow.Cells[2].Text);
        Loan.AnnualInterestRate = double.Parse(gvCustomerLoanList.SelectedRow.Cells[3].Text);
        Loan.Months = int.Parse(gvCustomerLoanList.SelectedRow.Cells[4].Text);
        lblPayment.Text = Loan.MonthlyPayment.ToString("C");
        gvAmortizationSchedule.DataSource = Loan.Schedule;
        gvAmortizationSchedule.DataBind();
    }
    protected void gvAmortizationSchedule_SelectedIndexChanged(object sender, EventArgs e)
    {
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Pages_AccountManagement : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void fvUserEdit_PageIndexChanging(object sender, FormViewPageEventArgs e)
    {

    }
    protected void fvUserEdit_ItemDeleted(object sender, FormViewDeletedEventArgs e)
    {
        sdsUserList.DataBind();
        gvUserList.DataBind();
    }
    protected void fvUserEdit_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {
        sdsUserList.DataBind();
        gvUserList.DataBind();
    }
}
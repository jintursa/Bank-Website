﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;

public partial class Pages_Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        try
        {
            //I want to get any users and check their passwords
            DataView dview = (DataView)sdsUserList.Select(DataSourceSelectArguments.Empty);
            
            foreach (DataRow drow in dview.Table.Rows)
            {
                if (drow["vcPassword"].ToString() == txtPassword.Text)
                {

                    Session["UserID"] = drow["pkUserID"].ToString();
                    Response.Redirect("Registered.aspx");

                }

            }

        }
        catch (Exception)
        {
            txtUserName.Focus();    
            
        }

        lblBadLogin.Visible = true;
    }

    protected void txtUserName_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        lblDisUser.Visible = true;
        lblDisPass.Visible = true;
    }
}
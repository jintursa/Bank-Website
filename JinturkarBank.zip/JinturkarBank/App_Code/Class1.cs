﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JinturkarLoan
{
    public class PaymentCalculator
    {
        //Public Properties manuipualte private valriables...!!!!

        //This will hold the iniatil value of the loan
        private double myPrincipal = 0;
        public double Principal
        {
            get
            {
                return myPrincipal;
            }
            set
            {
                if (value > 0)
                {
                    myPrincipal = value;
                }
            }
        }

        private double myMonthlyInterestRate = 0;
        public double AnnualInterestRate
        {
            get
            {
                return myMonthlyInterestRate * 12;
            }
            set
            {
                if(value>=0)
                {
                    if (value >= 1)
                    {
                        value = value / 100;
                    }
                    myMonthlyInterestRate = value / 12;
                }
            }
        }
        public double MonthlyInterestRate
        {
            get
            {
                return myMonthlyInterestRate;
            }
        }

        private int myMonths = 0;
        public int Months
        {
            get
            {
                return myMonths;
            }
            set
            {
                if (value > 0)
                {
                    myMonths = value;
                }
            }
        }
        public int Years
        {
            set
            {
                if (value > 0)
                {
                    myMonths = value * 12;
                }
            }
        }
        public double MonthlyPayment
        {
            get
            {
                double top =  myMonthlyInterestRate;
                double bottom = Math.Pow((1 + myMonthlyInterestRate), myMonths) - 1;
                double i = myMonthlyInterestRate + top / bottom;
                            
                return  i * myPrincipal;
            }
        }
        public AmortizationLine[] Schedule
        {
            get
            {
                return new AmortizationSchedule(myMonths, myPrincipal, myMonthlyInterestRate, MonthlyPayment).Schedule;
            }
        }
    }
    public class AmortizationLine
    {
        public AmortizationLine(int CurrentMonth, double CurrentBalance, double MonthlyPayment, double InterestRate)
        {
            mydblBeginningBalance = CurrentBalance;
            mydblInterestPaid = InterestRate * CurrentBalance;
            mydblPrincipalPaid = MonthlyPayment - mydblInterestPaid;
            mydblEndingBalance = CurrentBalance - mydblPrincipalPaid;
            myintMonth = CurrentMonth;
        }
        private double mydblBeginningBalance = 0;
        public double BeginningBalance
        {
            get
            {
                return mydblBeginningBalance;
            }
        }
        private double mydblEndingBalance = 0;
        public double EndingBalance
        {
            get
            {
                return mydblEndingBalance;
            }
        }
        private double mydblPrincipalPaid = 0;
        public double PrincipalPaid
        {
            get
            {
                return (Math.Round(mydblPrincipalPaid,2));
            }
        }
        private double mydblInterestPaid = 0;
        public double InterestPaid
        {
            get
            {
                return (Math.Round(mydblInterestPaid,2));
            }
        }
        private int myintMonth = 0;
        public int Month
        {
            get
            {
                return myintMonth;
            }
        }
    }
    public class AmortizationSchedule
    {
        public AmortizationSchedule(int NumberOfMonths, double BeginningAmount, double InterestRate, double MonthlyPayment)
        {
            mySchedule = new AmortizationLine[NumberOfMonths+1];
            mySchedule[0] = new AmortizationLine(0, BeginningAmount, MonthlyPayment, InterestRate);
            for (int intMonth = 1; intMonth <= NumberOfMonths; intMonth++)
            {
                mySchedule[intMonth] = new AmortizationLine(intMonth, mySchedule[intMonth - 1].EndingBalance, MonthlyPayment, InterestRate);
            }
        }
        private AmortizationLine[] mySchedule;
        public AmortizationLine[] Schedule
        {
            get
            {
                return mySchedule;
            }

        }
    }
}
